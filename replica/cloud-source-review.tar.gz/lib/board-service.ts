import {validateDocument} from './core/model.mjs';
import {applyChanges,Conflict} from './core/changes.mjs';
type Identity={id:string,email:string,name:string};
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
const fault=(status:number,message:string)=>Object.assign(new Error(message),{status});
function identity(request:Request):Identity{
  const id=request.headers.get('oai-authenticated-user-id'),email=request.headers.get('oai-authenticated-user-email');
  if(!id||!email)throw fault(401,'Sign in to use cloud boards');
  return{id,email:email.toLowerCase(),name:email.split('@')[0]};
}
async function body(request:Request){const text=await request.text();if(text.length>4_000_000)throw fault(413,'Board update exceeds 4 MB');try{return JSON.parse(text);}catch{throw fault(400,'Invalid JSON');}}
export async function boardAPI(request:Request,db:D1Database){
  try{
    const user=identity(request),url=new URL(request.url),path=url.pathname.replace(/^\/api\/?/,'').split('/').filter(Boolean),method=request.method;
    if(!['GET','HEAD'].includes(method)&&request.headers.get('origin')!==url.origin)throw fault(403,'Cross-origin writes are not allowed');
    if(!['GET','HEAD'].includes(method)){
      const category=path[2]==='presence'?'presence':path.length===1?'create':'write',maximum=category==='create'?30:600,bucket=Math.floor(Date.now()/60000);
      const limit=await db.prepare('INSERT INTO api_limits(key,count,expires_at) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').bind(`${user.id}:${category}:${bucket}`,(bucket+2)*60000).first<{count:number}>();
      if(limit&&limit.count>maximum)throw fault(429,'Too many updates. Your draft is preserved; retry shortly.');
    }
    if(path[0]==='me')return json({user});
    const access=async(id:string)=>{const row=await db.prepare('SELECT b.*, m.role AS member_role FROM boards b LEFT JOIN members m ON m.board_id=b.id AND m.email=? WHERE b.id=?').bind(user.email,id).first<any>();if(!row||row.owner_id!==user.id&&!row.member_role)throw fault(404,'Board not found');row.role=row.owner_id===user.id?'owner':row.member_role;return row;};
    const snapshot=(row:any)=>({id:row.id,doc:JSON.parse(row.document),revision:row.revision,role:row.role||'owner',updatedAt:row.updated_at});
    if(path[0]!=='boards')throw fault(404,'Unknown API route');
    if(path.length===1&&method==='GET'){
      const rows=await db.prepare('SELECT b.id,json_extract(b.document,\'$.name\') AS name,b.revision,b.updated_at,b.owner_id,m.role AS member_role FROM boards b LEFT JOIN members m ON m.board_id=b.id AND m.email=? WHERE b.owner_id=? OR m.role IS NOT NULL ORDER BY b.updated_at DESC').bind(user.email,user.id).all<any>();
      return json({boards:rows.results.map(row=>({id:row.id,name:row.name,revision:row.revision,updatedAt:row.updated_at,role:row.owner_id===user.id?'owner':row.member_role}))});
    }
    if(path.length===1&&method==='POST'){
      const input=await body(request);let doc;try{doc=validateDocument(input.doc);}catch{throw fault(400,'Invalid board document');}const id=crypto.randomUUID(),time=Date.now(),serialized=JSON.stringify(doc);
      if(new TextEncoder().encode(serialized).length>1_800_000)throw fault(413,'This board exceeds the current cloud document size limit');
      await db.prepare('INSERT INTO boards(id,owner_id,document,revision,updated_at,last_operation) VALUES(?,?,?,0,?,NULL)').bind(id,user.id,serialized,time).run();return json({id,doc,revision:0,role:'owner',updatedAt:time},201);
    }
    const id=path[1];if(!id)throw fault(404,'Board not found');let row=await access(id);
    if(path.length===2&&method==='GET')return json(snapshot(row));
    if(path[2]==='members'){
      if(row.role!=='owner')throw fault(403,'Only the owner can manage members');
      if(method==='GET')return json({members:(await db.prepare('SELECT email,role FROM members WHERE board_id=?').bind(id).all()).results});
      const input=await body(request);if(typeof input.email!=='string'||!/^\S+@\S+\.\S+$/.test(input.email)||input.email.length>254)throw fault(400,'Enter a valid email');
      if(method==='POST'){if(!['editor','commenter','viewer'].includes(input.role))throw fault(400,'Invalid member role');await db.prepare('INSERT INTO members(board_id,email,role) VALUES(?,?,?) ON CONFLICT(board_id,email) DO UPDATE SET role=excluded.role').bind(id,input.email.toLowerCase(),input.role).run();return json({ok:true});}
      if(method==='DELETE'){await db.prepare('DELETE FROM members WHERE board_id=? AND email=?').bind(id,input.email.toLowerCase()).run();return json({ok:true});}
    }
    if(path[2]==='changes'&&method==='POST'){
      if(!['owner','editor'].includes(row.role))throw fault(403,'This board is read-only');const input=await body(request);
      if(typeof input.operationId!=='string'||!/^[a-zA-Z0-9-]{10,100}$/.test(input.operationId))throw fault(400,'Invalid operation id');
      const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(input.changes))))).map(n=>n.toString(16).padStart(2,'0')).join('');
      for(let attempt=0;attempt<5;attempt++){
        const previous=await db.prepare('SELECT digest FROM mutations WHERE board_id=? AND operation_id=?').bind(id,input.operationId).first<any>();
        if(previous){if(previous.digest!==digest)throw fault(409,'Operation id already used for a different change');return json(snapshot(await access(id)));}
        row=await access(id);if(!['owner','editor'].includes(row.role))throw fault(403,'Editing permission was revoked');
        let doc;try{doc=applyChanges(JSON.parse(row.document),input.changes);}catch(error){if(error instanceof Conflict)return json({error:error.message,conflicts:error.conflicts,snapshot:snapshot(row)},409);throw fault(400,error instanceof Error?error.message:'Invalid change');}
        if(new TextEncoder().encode(JSON.stringify(doc)).length>1_800_000)throw fault(413,'This board exceeds the current cloud document size limit');
        const time=Date.now(),result=await db.batch([
          db.prepare('UPDATE boards SET document=?,revision=revision+1,updated_at=?,last_operation=? WHERE id=? AND revision=? AND (owner_id=? OR EXISTS(SELECT 1 FROM members WHERE board_id=boards.id AND email=? AND role=\'editor\'))').bind(JSON.stringify(doc),time,input.operationId,id,row.revision,user.id,user.email),
          db.prepare('INSERT OR IGNORE INTO mutations(board_id,operation_id,digest) SELECT id,?,? FROM boards WHERE id=? AND last_operation=?').bind(input.operationId,digest,id,input.operationId)
        ]);
        if(result[0].meta.changes)return json(snapshot({...row,document:JSON.stringify(doc),revision:row.revision+1,updated_at:time}));
      }throw fault(409,'Board is busy. Retry your update.');
    }
    if(path[2]==='presence'&&method==='POST'){
      const input=await body(request);if(typeof input.clientId!=='string'||!/^[a-zA-Z0-9-]{10,100}$/.test(input.clientId))throw fault(400,'Invalid client id');
      const x=Number.isFinite(input.x)?Math.max(-1e7,Math.min(1e7,input.x)):null,y=Number.isFinite(input.y)?Math.max(-1e7,Math.min(1e7,input.y)):null;
      await db.batch([db.prepare('INSERT INTO presence(board_id,client_id,user_id,name,x,y,seen_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(board_id,client_id) DO UPDATE SET x=excluded.x,y=excluded.y,seen_at=excluded.seen_at WHERE presence.user_id=excluded.user_id').bind(id,input.clientId,user.id,user.name,x,y,Date.now()),db.prepare('DELETE FROM presence WHERE seen_at<?').bind(Date.now()-60000)]);return json({ok:true});
    }
    if(path[2]==='events'&&method==='GET'){
      let cancelled=false,timer:ReturnType<typeof setTimeout>|null=null;const encoder=new TextEncoder();let revision=Number(url.searchParams.get('revision')||-1),role=row.role,ticks=0;
      const stream=new ReadableStream({start(controller){
        const poll=async()=>{if(cancelled)return;try{const latest=await access(id);if(latest.revision!==revision||latest.role!==role){revision=latest.revision;role=latest.role;controller.enqueue(encoder.encode(`event: board\ndata: ${JSON.stringify(snapshot(latest))}\n\n`));}
          const people=await db.prepare('SELECT client_id,name,x,y FROM presence WHERE board_id=? AND seen_at>?').bind(id,Date.now()-25000).all();controller.enqueue(encoder.encode(`event: presence\ndata: ${JSON.stringify(people.results)}\n\n`));
          if(++ticks>=20){cancelled=true;controller.close();return;}timer=setTimeout(poll,1000);
        }catch{cancelled=true;try{controller.enqueue(encoder.encode('event: revoked\ndata: {}\n\n'));controller.close();}catch{}}};void poll();
      },cancel(){cancelled=true;if(timer)clearTimeout(timer);}});
      return new Response(stream,{headers:{'Content-Type':'text/event-stream','Cache-Control':'no-cache, no-transform','X-Accel-Buffering':'no'}});
    }
    throw fault(405,'Unsupported operation');
  }catch(error){const err=error as Error&{status?:number};return json({error:err.status?err.message:'Cloud request failed'},err.status||500);}
}
