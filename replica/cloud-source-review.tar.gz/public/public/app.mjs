import {Board,bounds,reconcileFrames} from '/src/model.mjs';
import {LocalLibrary,LIBRARY_KEY} from '/src/library.mjs';
import {SHAPES,shapeGeometry,connectorGeometry,localDelta,resizedOrigin} from '/src/geometry.mjs';
import {autoFontSize} from '/src/typography.mjs';
import {CloudSession,cloudRequest} from '/src/cloud-client.mjs';
import {changesBetween,applyChanges,equal} from '/src/changes.mjs';
const $=id=>document.getElementById(id), ns='http://www.w3.org/2000/svg';
let board, library, storageError=false, saveBlocked=false;
try { library=new LocalLibrary(localStorage);board=library.state.activeId?new Board(library.get().doc):new Board(); } catch { board=new Board(); storageError=true;saveBlocked=true; }
let selected=[], tool='select', camera={x:100,y:100,z:1}, gesture=null, connectFrom=null, presentation=-1;
let creationShape='rectangle',stickyFill='#f6e49b',stickySize={w:180,h:180},lastPointer=null;
let cloudSession=null,deferredCloud=null,cursorSentAt=0,cloudPeople=[],lastObjectPress=null;
const writable=()=>!cloudSession||cloudSession.canEdit;
const FONTS={sans:'system-ui, sans-serif',serif:'Georgia, serif',mono:'monospace'};
const measureContext=document.createElement('canvas').getContext('2d');
const canvas=$('canvas'), scene=$('scene');
function toast(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,3500);}
function persist(){if(cloudSession){if(!writable()&&equal(board.doc,cloudSession.base.doc))return true;try{localStorage.setItem('mirra.cloud.draft.'+cloudSession.base.id,JSON.stringify({revision:cloudSession.base.revision,doc:board.doc}));cloudSession.setDocument(board.doc);return true;}catch(error){$('save').textContent=error.message;return false;}}if(saveBlocked){$('save').textContent='Not saved — export to keep changes';return false;}try{library.save(board.doc);$('save').textContent='Saved on this device';return true;}catch(error){$('save').textContent='Save failed — export your board';toast(error.message);return false;}}
function world(event){const r=canvas.getBoundingClientRect();return{x:(event.clientX-r.left-camera.x)/camera.z,y:(event.clientY-r.top-camera.y)/camera.z};}
function el(tag,attrs={}){const node=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(attrs))node.setAttribute(k,v);return node;}
function fontSize(item){if(!item.autoFont)return item.fontSize||(item.type==='text'?22:17);return autoFontSize(item.text,item.w-28,item.h-28,(text,size)=>{measureContext.font=`${item.bold?'bold ':''}${item.italic?'italic ':''}${size}px ${FONTS[item.fontFamily||'sans']}`;return measureContext.measureText(text).width;});}
function textContent(group,item){const f=el('foreignObject',{x:0,y:0,width:item.w,height:item.h});const div=document.createElement('div');div.className='itemtext';const content=document.createElement('span');content.textContent=item.text;content.style.width='100%';content.style.textAlign=item.textAlign||(item.type==='text'?'left':'center');Object.assign(div.style,{fontSize:`${fontSize(item)}px`,fontFamily:FONTS[item.fontFamily||'sans'],fontWeight:item.bold?'700':'400',fontStyle:item.italic?'italic':'normal',textDecoration:item.underline?'underline':'none',color:item.textColor||'#22372f'});div.append(content);f.append(div);group.append(f);}
function render(){
  scene.replaceChildren();scene.setAttribute('transform',`translate(${camera.x} ${camera.y}) scale(${camera.z})`);
  $('dots').setAttribute('patternTransform',`translate(${camera.x} ${camera.y}) scale(${camera.z})`);
  const frames=board.doc.items.filter(i=>i.type==='frame').sort((a,b)=>b.w*b.h-a.w*a.h);
  for(const item of [...frames,...board.doc.items.filter(i=>i.type!=='frame')]){
    const group=el('g',{'data-id':item.id,'data-type':item.type,class:`object ${selected.includes(item.id)?'selected':''}`,transform:`translate(${item.x} ${item.y}) rotate(${item.rotation||0} ${item.w/2} ${item.h/2})`,opacity:item.opacity??1});
    group.style.setProperty('--item-stroke',selected.includes(item.id)?'#176b50':item.stroke||'#a5b8ae');group.style.setProperty('--item-stroke-width',selected.includes(item.id)?'2':String(item.strokeWidth??1));
    const dash=item.lineStyle==='dashed'?'10 6':item.lineStyle==='dotted'?'2 5':'none';
    if(item.type==='connector'){
      const from=board.doc.items.find(i=>i.id===item.from),to=board.doc.items.find(i=>i.id===item.to);
      group.setAttribute('transform','');const geometry=connectorGeometry(from,to,item.route),arrow=item.arrow||'end';
      group.append(el('path',{d:geometry.path,fill:'none',stroke:'transparent','stroke-width':16}),el('path',{d:geometry.path,fill:'none',stroke:selected.includes(item.id)?'#176b50':item.stroke||item.fill,'stroke-width':item.strokeWidth??2,'stroke-dasharray':dash,'marker-end':arrow==='none'?'none':'url(#arrow)','marker-start':arrow==='both'?'url(#arrow)':'none'}));
      if(item.text){const label=el('text',{x:geometry.mid.x,y:geometry.mid.y-8,'text-anchor':'middle',fill:item.textColor||'#22372f',stroke:'#ffffff','stroke-width':4,'paint-order':'stroke','stroke-linejoin':'round','font-size':item.fontSize||14,'font-family':FONTS[item.fontFamily||'sans'],'font-weight':item.bold?'700':'400','font-style':item.italic?'italic':'normal','text-decoration':item.underline?'underline':'none'});label.textContent=item.text;group.append(label);}
    }else if(item.type==='pen'){
      const d=item.points.map((p,i)=>`${i?'L':'M'}${p[0]} ${p[1]}`).join(' ');group.append(el('path',{d,fill:'none',stroke:item.stroke||item.fill,'stroke-width':item.strokeWidth??3,'stroke-dasharray':dash,'stroke-linecap':'round','stroke-linejoin':'round'}));
    }else if(item.type==='frame'){
      group.append(el('rect',{width:item.w,height:item.h,fill:item.fill,'fill-opacity':.25,rx:4}));const label=el('text',{x:0,y:-12,class:'frame-title'});label.textContent=item.text||'Frame';group.append(label);
    }else{
      if(item.type!=='text'){const shape=shapeGeometry(item.type==='card'?'rounded':item.shape,item.w,item.h);group.append(el(shape.tag,{...shape.attrs,fill:item.fill,stroke:item.stroke||'#a5b8ae','stroke-width':item.strokeWidth??1,'stroke-dasharray':dash}));}textContent(group,item);
    }
    if(selected.includes(item.id)&&item.type!=='connector'&&!item.locked)group.append(el('rect',{x:item.w-5,y:item.h-5,width:10,height:10,class:'resize','data-resize':item.id}));
    if(item.locked){const lock=el('text',{x:4,y:15,'font-size':12});lock.textContent='🔒';group.append(lock);}
    scene.append(group);
  }
  if(document.activeElement!==$('title'))$('title').value=board.doc.name;$('zoom').textContent=`${Math.round(camera.z*100)}%`;$('selectionbar').hidden=!selected.length||presentation>=0;
  const firstSelected=board.doc.items.find(i=>selected.includes(i.id));if(firstSelected)$('fill').value=firstSelected.fill;
  $('undo').disabled=!board.past.length||!writable();$('redo').disabled=!board.future.length||!writable();$('title').readOnly=!writable();$('import').disabled=!writable();
  document.querySelectorAll('[data-tool]').forEach(b=>b.disabled=!writable()&&!['hand','select'].includes(b.dataset.tool));
  document.querySelectorAll('#selectionbar button,#selectionbar input,#selectionbar select').forEach(b=>b.disabled=!writable()&&b.id!=='copy');
  document.querySelectorAll('[data-tool]').forEach(b=>b.classList.toggle('active',b.dataset.tool===tool));
  renderPresence();
}
function renderPresence(){scene.querySelector('#live-cursors')?.remove();if(!cloudSession)return;const layer=el('g',{id:'live-cursors','pointer-events':'none'});for(const person of cloudPeople){if(!Number.isFinite(person.x)||!Number.isFinite(person.y))continue;const g=el('g',{transform:`translate(${person.x} ${person.y}) scale(${1/camera.z})`});g.append(el('path',{d:'M0 0 L0 18 L5 13 L10 23 L14 21 L9 11 L17 11 Z',fill:'#8050a0',stroke:'#ffffff','stroke-width':1}));const text=el('text',{x:18,y:26,fill:'#63357d','font-size':12,stroke:'#ffffff','stroke-width':3,'paint-order':'stroke'});text.textContent=person.name;g.append(text);layer.append(g);}scene.append(layer);}
function changed(){selected=selected.filter(id=>board.doc.items.some(i=>i.id===id));persist();render();}
function setTool(value){tool=value;connectFrom=null;canvas.style.cursor=value==='hand'?'grab':value==='select'?'default':'crosshair';render();}
function edit(id){const item=board.doc.items.find(i=>i.id===id);if(!writable()||!item||item.locked||item.type==='pen')return;selected=[id];$('content').value=item.text;$('content').maxLength=item.type==='sticky'?3000:100000;$('editor').dataset.item=id;$('editor').returnValue='cancel';$('editor').showModal();$('content').focus();}
$('editor').addEventListener('close',()=>{if($('editor').returnValue==='save'){board.update([$('editor').dataset.item],{text:$('content').value});changed();}});
function fit(items=board.doc.items){const box=bounds(items.filter(i=>i.type!=='connector'));camera.z=Math.min(2,Math.max(.05,Math.min((innerWidth-200)/(box.w+100),(innerHeight-220)/(box.h+100))));camera.x=(innerWidth-box.w*camera.z)/2-box.x*camera.z;camera.y=(innerHeight-box.h*camera.z)/2-box.y*camera.z;render();}
canvas.addEventListener('pointerdown',e=>{
  if(e.button!==0&&e.button!==1)return; if(presentation>=0)return;
  const p=world(e),target=e.target.closest('[data-id]'),id=target?.dataset.id,item=board.doc.items.find(i=>i.id===id);
  canvas.setPointerCapture(e.pointerId);
  if(tool==='hand'||e.button===1||e.altKey){gesture={type:'pan',sx:e.clientX,sy:e.clientY,original:{...camera}};return;}
  if(!writable()){if(id)selected=board.selection([id]);else selected=[];render();return;}
  if(tool==='connector'){
    if(!item||['connector','frame'].includes(item.type))return;
    if(!connectFrom){connectFrom=id;selected=[id];toast('Click another object to connect it.');render();}else if(id!==connectFrom){const from=connectFrom;selected=[board.add('connector',0,0,{from,to:id,fill:'#526961'})];setTool('select');changed();}return;
  }
  if(tool==='pen'){gesture={type:'pen',start:p,points:[[0,0]]};return;}
  if(tool!=='select'){
    const props={sticky:{text:'',...stickySize,fill:stickyFill,autoFont:true},text:{text:'',w:240,h:100,fill:'#ffffff'},shape:{text:'',fill:'#e1eee7',shape:creationShape},frame:{text:'New frame',w:650,h:430,fill:'#ffffff'},card:{text:'New task\n\nAdd a description',w:260,h:160,fill:'#ffffff'}}[tool];
    const created=board.add(tool,p.x,p.y,props);selected=[created];const createdType=tool;setTool('select');changed();if(createdType!=='frame')edit(created);return;
  }
  if(id){
    const now=Date.now();if(!e.shiftKey&&lastObjectPress?.id===id&&now-lastObjectPress.time<400){lastObjectPress=null;edit(id);return;}lastObjectPress={id,time:now};
    if(e.shiftKey){selected=selected.includes(id)?selected.filter(x=>x!==id):[...selected,id];render();return;}
    if(!selected.includes(id))selected=board.selection([id]);
    gesture={type:e.target.dataset.resize?'resize':'move',start:p,original:structuredClone(board.doc),id};
  }else{selected=[];gesture={type:'marquee',start:p};}render();
});
canvas.addEventListener('pointermove',e=>{
  lastPointer=world(e);if(cloudSession&&Date.now()-cursorSentAt>500){cursorSentAt=Date.now();void cloudSession.presence(lastPointer).catch(()=>{});}if(!gesture)return;const p=world(e),g=gesture;
  if(g.type==='pan'){camera.x=g.original.x+e.clientX-g.sx;camera.y=g.original.y+e.clientY-g.sy;render();return;}
  if(g.type==='move'||g.type==='resize'){
    board.doc=structuredClone(g.original);const dx=p.x-g.start.x,dy=p.y-g.start.y;
    const moving=board.selection(selected.filter(id=>!board.doc.items.find(i=>i.id===id)?.locked),{descendants:true});
    for(const i of board.doc.items)if(moving.includes(i.id)&&!i.locked&&i.type!=='connector'){if(g.type==='move'){i.x+=dx;i.y+=dy;}else if(i.id===g.id){const delta=localDelta(dx,dy,i.rotation),w=Math.max(30,i.w+delta.x),h=Math.max(30,i.h+delta.y),origin=resizedOrigin(i,w,h);if(i.type==='pen')i.points=i.points.map(p=>[p[0]*w/i.w,p[1]*h/i.h]);i.x=origin.x;i.y=origin.y;i.w=w;i.h=h;}}render();
  }else if(g.type==='marquee'){
    const x=Math.min(p.x,g.start.x),y=Math.min(p.y,g.start.y),w=Math.abs(p.x-g.start.x),h=Math.abs(p.y-g.start.y);
    selected=board.doc.items.filter(i=>i.type!=='connector'&&i.x>=x&&i.y>=y&&i.x+i.w<=x+w&&i.y+i.h<=y+h).map(i=>i.id);render();scene.append(el('rect',{x,y,width:w,height:h,class:'marquee'}));
  }else if(g.type==='pen'){
    g.points.push([p.x-g.start.x,p.y-g.start.y]);render();scene.append(el('path',{d:g.points.map((v,i)=>`${i?'L':'M'}${v[0]+g.start.x} ${v[1]+g.start.y}`).join(' '),stroke:'#233c33','stroke-width':3,fill:'none'}));
  }
});
function endGesture(cancel=false){
  const g=gesture;if(!g)return;gesture=null;
  if(g.original&&['move','resize'].includes(g.type)){let result=structuredClone(board.doc);reconcileFrames(result);board.doc=g.original;if(deferredCloud){const latest=deferredCloud;deferredCloud=null;if(cancel){board.doc=latest;result=latest;}else try{result=applyChanges(latest,changesBetween(g.original,result));board.doc=latest;}catch(error){if(cloudSession)cloudSession.conflict=error;board.doc=result;toast('A live edit conflicts with this drag. Export your draft before reloading.');}}if(!cancel)board.transact(doc=>Object.assign(doc,result));}
  if(g.type==='pen'&&!cancel&&g.points.length>1){const xs=g.points.map(p=>p[0]),ys=g.points.map(p=>p[1]),minX=Math.min(...xs),minY=Math.min(...ys);selected=[board.add('pen',g.start.x+minX,g.start.y+minY,{w:Math.max(1,Math.max(...xs)-minX),h:Math.max(1,Math.max(...ys)-minY),fill:'#233c33',points:g.points.map(p=>[p[0]-minX,p[1]-minY])})];}changed();
}
canvas.addEventListener('pointerup',()=>endGesture());canvas.addEventListener('pointercancel',()=>endGesture(true));
canvas.addEventListener('dblclick',e=>{const id=e.target.closest('[data-id]')?.dataset.id;if(id)edit(id);});
canvas.addEventListener('wheel',e=>{e.preventDefault();if(e.ctrlKey||e.metaKey){const p=world(e);camera.z=Math.min(4,Math.max(.05,camera.z*Math.exp(-e.deltaY*.005)));camera.x=e.clientX-p.x*camera.z;camera.y=e.clientY-p.y*camera.z;}else{camera.x-=e.deltaX;camera.y-=e.deltaY;}render();},{passive:false});
document.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>{setTool(b.dataset.tool);if(b.dataset.tool==='shape')panel('shapes');if(b.dataset.tool==='sticky')panel('stickies');});
let titleSaveTimer;
function commitTitle(value){if(!writable())return;board.transact(doc=>doc.name=value.trim()||'Untitled board');document.title=board.doc.name+(cloudSession?' · Mirra Cloud':' · Mirra');changed();}
$('title').onchange=()=>{clearTimeout(titleSaveTimer);commitTitle($('title').value);};
$('title').oninput=event=>{clearTimeout(titleSaveTimer);const value=event.target.value,current=board;titleSaveTimer=setTimeout(()=>{if(board===current)commitTitle(value);},400);};
$('undo').onclick=()=>{board.undo();changed();};$('redo').onclick=()=>{board.redo();changed();};
$('fill').oninput=e=>{board.update(selected,{fill:e.target.value});changed();};
$('edit').onclick=()=>edit(selected[0]);$('duplicate').onclick=()=>{selected=board.duplicate(selected);changed();};
$('delete').onclick=()=>{board.remove(selected);changed();};$('lock').onclick=()=>{const unlocked=board.doc.items.some(i=>selected.includes(i.id)&&!i.locked);board.update(selected,{locked:unlocked});changed();};
$('align').onchange=e=>{board.align(selected,e.target.value);e.target.value='';changed();};$('front').onclick=()=>{board.reorder(selected,true);changed();};
$('group').onclick=()=>{try{selected=board.group(selected);changed();}catch(error){toast(error.message);}};
$('ungroup').onclick=()=>{selected=board.ungroup(selected);changed();};
$('frame-selection').onclick=()=>{try{selected=[board.frameSelection(selected)];changed();}catch(error){toast(error.message);}};
const numericProps=['x','y','w','h','rotation','opacity','fontSize','strokeWidth'];
const booleanProps=['bold','italic','underline','autoFont'];
const valueProps=['fill','stroke','textColor','fontFamily','textAlign','shape','route','arrow','lineStyle'];
function inspect(){
  if(selected.length!==1){toast('Select one object to edit its properties.');return;}
  const item=board.doc.items.find(i=>i.id===selected[0]);if(item.locked){toast('Unlock this object before changing properties.');return;}
  const defaults={rotation:0,opacity:1,fontSize:item.type==='text'?22:17,strokeWidth:item.type==='connector'?2:item.type==='pen'?3:1,stroke:item.type==='connector'||item.type==='pen'?item.fill:'#a5b8ae',textColor:'#22372f',fontFamily:'sans',textAlign:item.type==='text'?'left':'center',shape:'rectangle',route:'straight',arrow:'end',lineStyle:'solid'};
  for(const key of [...numericProps,...valueProps])$('prop-'+key).value=item[key]??defaults[key];
  for(const key of booleanProps)$('prop-'+key).checked=Boolean(item[key]);
  $('geometryfields').hidden=item.type==='connector';$('textfields').hidden=item.type==='pen';$('shapefield').hidden=item.type!=='shape';$('connectorfields').hidden=item.type!=='connector';
  $('inspector').dataset.item=item.id;$('inspecterror').textContent='';$('inspector').showModal();
}
$('inspect').onclick=inspect;$('cancelinspect').onclick=()=>$('inspector').close();
$('inspectform').onsubmit=e=>{
  e.preventDefault();try{
    const id=$('inspector').dataset.item,original=board.doc.items.find(i=>i.id===id);if(!original||original.locked)throw Error('Select an unlocked object');
    const temp=new Board(board.doc),props={};
    for(const key of numericProps){const raw=$('prop-'+key).value;if(raw==='')throw Error('Numeric properties cannot be empty');props[key]=Number(raw);}
    for(const key of booleanProps)props[key]=$('prop-'+key).checked;
    for(const key of valueProps)props[key]=$('prop-'+key).value;
    if(original.type!=='connector'){temp.move([id],props.x-original.x,props.y-original.y);temp.resize(id,props.w,props.h);}else{delete props.x;delete props.y;delete props.w;delete props.h;delete props.rotation;}
    delete props.x;delete props.y;delete props.w;delete props.h;
    if(original.type!=='shape')delete props.shape;
    temp.update([id],props);board.transact(doc=>Object.assign(doc,temp.doc));changed();$('inspector').close();
  }catch(error){$('inspecterror').textContent=error.message;}
};
const CLIP_PREFIX='MIRRA_SELECTION_V1\n';
function canEditClipboard(event){return!$('workspace').hidden&&presentation<0&&!event.target.closest('input,textarea,select,dialog');}
for(const type of ['copy','cut'])document.addEventListener(type,e=>{
  if(!canEditClipboard(e)||!selected.length)return;e.preventDefault();e.clipboardData.setData('text/plain',CLIP_PREFIX+board.copySelection(selected));if(type==='cut'&&writable()){board.remove(board.selection(selected.filter(id=>!board.doc.items.find(i=>i.id===id)?.locked),{descendants:true}));changed();}
});
document.addEventListener('paste',e=>{
  if(!canEditClipboard(e)||!writable())return;const text=e.clipboardData.getData('text/plain');if(!text)return;e.preventDefault();
  try{const p=lastPointer||world({clientX:innerWidth/2,clientY:innerHeight/2});selected=text.startsWith(CLIP_PREFIX)?board.pasteSelection(text.slice(CLIP_PREFIX.length),p.x+24,p.y+24):[board.add('text',p.x,p.y,{w:280,h:160,text,fill:'#ffffff'})];changed();}catch(error){toast(`Paste failed: ${error.message}`);}
});
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText(CLIP_PREFIX+board.copySelection(selected));toast('Selection copied. Paste on this board or another board.');}catch{toast('Use Ctrl/Cmd+C while the canvas has focus to copy.');}};
$('cancelbulk').onclick=()=>$('bulkdialog').close();
$('bulkform').onsubmit=e=>{e.preventDefault();try{const p=world({clientX:innerWidth/2-250,clientY:innerHeight/2-100});selected=board.bulkStickies($('bulktext').value,p.x,p.y,{fill:stickyFill,columns:Number($('bulkcolumns').value)});changed();setTool('select');$('bulkdialog').close();$('panel').hidden=true;fit(selected.map(id=>board.doc.items.find(i=>i.id===id)));}catch(error){$('bulkerror').textContent=error.message;}};
function zoom(factor){const x=innerWidth/2,y=innerHeight/2,p={x:(x-camera.x)/camera.z,y:(y-camera.y)/camera.z};camera.z=Math.min(4,Math.max(.05,camera.z*factor));camera.x=x-p.x*camera.z;camera.y=y-p.y*camera.z;render();}
$('plus').onclick=()=>zoom(1.2);$('minus').onclick=()=>zoom(1/1.2);$('zoom').onclick=()=>{zoom(1/camera.z);};$('fit').onclick=()=>fit();
function download(name,body,type){const url=URL.createObjectURL(new Blob([body],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('share').onclick=()=>$('exportdialog').showModal();$('closeexport').onclick=()=>$('exportdialog').close();
$('downloadjson').onclick=()=>download('mirra-board.json',board.serialize(),'application/json');
$('downloadsvg').onclick=()=>{
  const box=bounds(board.doc.items.filter(i=>i.type!=='connector')),out=canvas.cloneNode(true);
  out.querySelector('#grid').remove();out.querySelector('#scene').removeAttribute('transform');out.querySelectorAll('.resize').forEach(n=>n.remove());out.querySelectorAll('.selected').forEach(n=>n.classList.remove('selected'));
  const originals=[...canvas.querySelectorAll('.itemtext')];
  out.querySelectorAll('.itemtext').forEach((node,index)=>{const computed=getComputedStyle(originals[index]);for(const property of ['display','height','width','align-items','justify-content','padding','box-sizing','line-height','white-space','overflow-wrap','overflow'])node.style.setProperty(property,computed.getPropertyValue(property));});
  out.setAttribute('xmlns',ns);out.setAttribute('viewBox',`${box.x-30} ${box.y-40} ${box.w+60} ${box.h+70}`);out.setAttribute('width',box.w+60);out.setAttribute('height',box.h+70);download('mirra-board.svg',new XMLSerializer().serializeToString(out),'image/svg+xml');
};
$('import').onchange=async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>10*1024*1024)throw Error('The board file exceeds 10 MB');const incoming=Board.parse(await file.text());board.transact(doc=>Object.assign(doc,incoming.doc));selected=[];changed();fit();$('exportdialog').close();toast('Board imported. Undo restores your previous board.');}catch(error){toast(`Import failed: ${error.message}`);}e.target.value='';};
function panel(name){$('panel').hidden=false;$('paneltitle').textContent={layers:'Board objects',search:'Find on this board',templates:'Start with a layout',menu:'Board options',shapes:'Choose a shape',stickies:'Sticky notes'}[name];const body=$('panelbody');body.replaceChildren();
  const button=(label,action)=>{const b=document.createElement('button');b.textContent=label;b.onclick=action;body.append(b);return b;};
  function list(query=''){body.querySelectorAll('button').forEach(b=>b.remove());for(const i of [...board.doc.items].reverse().filter(i=>i.type!=='connector'&&i.text.toLowerCase().includes(query.toLowerCase())))button(`${i.type} · ${i.text||'Untitled'}`,()=>{selected=[i.id];fit([i]);});}
  if(name==='layers')list();
  if(name==='shapes')for(const shape of SHAPES)button(shape[0].toUpperCase()+shape.slice(1),()=>{creationShape=shape;setTool('shape');$('panel').hidden=true;toast('Click the canvas to place your shape.');});
  if(name==='stickies'){
    const colors=['#f6e49b','#f2c49a','#eeb4ab','#e5b9cb','#d8bce5','#c9c2ec','#becff0','#b5dce9','#b6e2dd','#c8e6ca','#dce7ae','#e9deb7','#e1d1bf','#dedee2','#f0e9de','#ffffff'];
    const palette=document.createElement('div');palette.className='notepalette';for(const color of colors){const b=document.createElement('button');b.style.background=color;b.setAttribute('aria-label',`Sticky color ${color}`);b.onclick=()=>{stickyFill=color;setTool('sticky');};palette.append(b);}body.append(palette);
    button('Square note',()=>{stickySize={w:180,h:180};setTool('sticky');$('panel').hidden=true;});
    button('Wide note',()=>{stickySize={w:240,h:140};setTool('sticky');$('panel').hidden=true;});
    button('Add notes in a batch',()=>{$('bulkerror').textContent='';$('bulkdialog').showModal();$('bulktext').focus();});
  }
  if(name==='search'){const input=document.createElement('input');input.placeholder='Search object text';input.setAttribute('aria-label','Search object text');input.oninput=()=>list(input.value);body.append(input);list();input.focus();}
  if(name==='templates')for(const label of ['Retrospective','Kanban','Brainstorm'])button(label,()=>{
    const labels=label==='Retrospective'?['What worked','What to improve','Next actions']:label==='Kanban'?['Ready','In progress','Complete']:['Challenge','Ideas','Experiments'];
    const origin=world({clientX:innerWidth/2-400,clientY:innerHeight/2-200});
    // A template insertion is a single undoable action.
    const temp=new Board(board.doc);labels.forEach((title,index)=>{temp.add('frame',origin.x+index*290,origin.y,{w:270,h:430,text:title,fill:'#ffffff'});temp.add('sticky',origin.x+index*290+30,origin.y+50,{text:'Add your thinking',w:200,h:150,fill:['#f6e49b','#d5e9dd','#e8dbef'][index]});});
    board.transact(doc=>Object.assign(doc,temp.doc));changed();fit();$('panel').hidden=true;
  });
  if(name==='menu'){
    button('Export or import a board',()=>$('exportdialog').showModal());button('Fit all objects',()=>fit());button('Toggle background grid',()=>{$('grid').hidden=!$('grid').hidden;$('grid').style.display=$('grid').hidden?'none':'';});
    button('Back to all boards',()=>showDashboard());button('Create another board',()=>createBoard());
    const p=document.createElement('p');p.textContent='Local prototype. Cloud sharing, accounts, live collaboration, AI and integrations are still under development.';body.append(p);
  }
}
document.querySelectorAll('[data-panel]').forEach(b=>b.onclick=()=>panel(b.dataset.panel));$('menu').onclick=()=>panel('menu');$('closepanel').onclick=()=>$('panel').hidden=true;
function showFrame(index){const frames=board.doc.items.filter(i=>i.type==='frame'&&!i.parentId);if(!frames.length){toast('Add a frame before presenting.');return;}presentation=(index+frames.length)%frames.length;fit([frames[presentation]]);document.body.classList.add('presenting');$('presentation').hidden=false;$('framename').textContent=`${presentation+1} / ${frames.length} · ${frames[presentation].text}`;$('panel').hidden=true;render();}
function endPresentation(){presentation=-1;document.body.classList.remove('presenting');$('presentation').hidden=true;render();}
$('present').onclick=()=>showFrame(0);$('prevframe').onclick=()=>showFrame(presentation-1);$('nextframe').onclick=()=>showFrame(presentation+1);$('endpresent').onclick=endPresentation;
document.addEventListener('keydown',e=>{
  if($('workspace').hidden||e.target.closest('input,textarea,select,dialog'))return;const key=e.key.toLowerCase(),mod=e.ctrlKey||e.metaKey;
  if(key==='escape'){endGesture(true);endPresentation();selected=[];setTool('select');$('panel').hidden=true;return;}
  if(presentation>=0){if(e.key==='ArrowRight')showFrame(presentation+1);if(e.key==='ArrowLeft')showFrame(presentation-1);return;}
  if(!writable()&&!(mod&&['a','f','c'].includes(key)))return;
  if(mod&&key==='z'){e.preventDefault();e.shiftKey?board.redo():board.undo();changed();return;}
  if(mod&&key==='a'){e.preventDefault();selected=board.doc.items.map(i=>i.id);render();return;}
  if(mod&&key==='d'){e.preventDefault();selected=board.duplicate(selected);changed();return;}
  if(mod&&key==='g'){e.preventDefault();try{selected=e.shiftKey?board.ungroup(selected):board.group(selected);changed();}catch(error){toast(error.message);}return;}
  if(mod&&key==='f'){e.preventDefault();panel('search');return;}
  if(!writable())return;
  if(mod&&key==='backspace'){e.preventDefault();board.clearContent(selected);changed();return;}
  if(mod&&['b','i','u'].includes(key)&&selected.length){e.preventDefault();const prop={b:'bold',i:'italic',u:'underline'}[key],first=board.doc.items.find(i=>selected.includes(i.id));board.update(selected.filter(id=>!board.doc.items.find(i=>i.id===id)?.locked),{[prop]:!first[prop]});changed();return;}
  if(['delete','backspace'].includes(key)){e.preventDefault();board.remove(selected);changed();return;}
  if(e.key.startsWith('Arrow')&&selected.length){e.preventDefault();const d=e.shiftKey?10:1;board.move(selected,e.key==='ArrowLeft'?-d:e.key==='ArrowRight'?d:0,e.key==='ArrowUp'?-d:e.key==='ArrowDown'?d:0);changed();return;}
  if(key==='enter'&&selected.length){edit(selected[0]);return;}
  const shortcut={v:'select',h:'hand',n:'sticky',t:'text',s:'shape',r:'shape',o:'shape',l:'connector',p:'pen',f:'frame',k:'card',d:'card'}[key];if(!mod&&shortcut){if(key==='r')creationShape='rectangle';if(key==='o')creationShape='ellipse';setTool(shortcut);if(key==='s')panel('shapes');if(key==='n')panel('stickies');}
});
let dashView='recent',dashSpace=null;
function requestName(heading,value,maximum=500){
  return new Promise(resolve=>{$('nameheading').textContent=heading;$('namevalue').value=value;$('namevalue').maxLength=maximum;$('namedialog').returnValue='cancel';$('namedialog').addEventListener('close',()=>resolve($('namedialog').returnValue==='save'?$('namevalue').value.trim():null),{once:true});$('namedialog').showModal();$('namevalue').focus();$('namevalue').select();});
}
function libraryAction(fn){try{if(saveBlocked||!library)throw Error('Library unavailable. Export your work and reload.');fn();renderDashboard();return true;}catch(error){toast(error.message);return false;}}
async function openBoard(id,{saveCurrent=true}={}){
  if(!await leaveCloud())return;
  try{if(saveBlocked)throw Error('Export unsaved work and reload before switching boards.');if(saveCurrent&&!$('workspace').hidden&&library.state.activeId&&!persist())return;const entry=library.open(id);board=new Board(entry.doc);selected=[];gesture=null;camera={x:100,y:100,z:1};$('dashboard').hidden=true;$('workspace').hidden=false;location.hash=`board/${id}`;document.title=`${entry.doc.name} · Mirra`;setTool('select');if(board.doc.items.length)fit();render();}
  catch(error){toast(error.message);}
}
async function showDashboard(){
  const wasCloud=Boolean(cloudSession);if(!await leaveCloud())return;
  if(!wasCloud&&!$('workspace').hidden&&library?.state.activeId&&!persist()){toast('Export unsaved changes before leaving this board.');return;}
  endPresentation();$('workspace').hidden=true;$('dashboard').hidden=false;$('panel').hidden=true;location.hash='home';document.title='Boards · Mirra';renderDashboard();
}
async function createBoard(){
  if(!await leaveCloud())return;
  const name=await requestName('Create a board','Untitled board');if(!name)return;
  if(!$('workspace').hidden&&library?.state.activeId&&!persist())return;
  let id;if(libraryAction(()=>id=library.create(name,dashSpace)))openBoard(id,{saveCurrent:false});
}
function renderDashboard(){
  $('dashtitle').textContent=dashSpace?library?.state.spaces.find(s=>s.id===dashSpace)?.name||'Space':{recent:'Recent boards',starred:'Starred boards',trash:'Trash'}[dashView];
  document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',!dashSpace&&b.dataset.view===dashView));
  $('spaces').replaceChildren();for(const space of library?.state.spaces||[]){const b=document.createElement('button');b.textContent=space.name;b.classList.toggle('active',space.id===dashSpace);b.onclick=()=>{dashSpace=space.id;dashView='recent';renderDashboard();};$('spaces').append(b);}
  $('dashboardnotice').textContent=saveBlocked?'A newer tab or a storage error has stopped saving. Keep a backup before reloading.':dashView==='trash'?'Boards in trash stay recoverable on this device.':'Your boards are stored in this browser. Export backups to keep an additional copy.';
  if(saveBlocked){const recover=document.createElement('button');recover.textContent='Export library recovery file';recover.onclick=()=>{try{download('mirra-library-recovery.json',localStorage.getItem(LIBRARY_KEY)||'{}','application/json');}catch(error){toast(error.message);}};$('dashboardnotice').append(' ',recover);}
  $('boardlist').replaceChildren();const entries=library?.list({query:$('boardsearch').value,view:dashView,spaceId:dashSpace,sort:$('boardsort').value})||[];
  $('dashempty').hidden=entries.length>0;$('emptytitle').textContent=dashView==='trash'?'Trash is empty':$('boardsearch').value?'No matching boards':'No boards here yet';$('emptydescription').textContent=dashView==='starred'?'Star a board to find it quickly here.':dashView==='trash'?'Removed boards will appear here for recovery.':$('boardsearch').value?'Try a different board name.':'Create a board to give your ideas a place to grow.';
  for(const entry of entries){
    const article=document.createElement('article');article.className='boardcard';article.setAttribute('aria-label',entry.doc.name);
    const cover=document.createElement('button');cover.className='boardcover';cover.setAttribute('aria-label',`Open ${entry.doc.name}`);cover.disabled=entry.deletedAt!==null;cover.onclick=()=>openBoard(entry.id);
    const preview=el('svg',{viewBox:'0 0 320 150','aria-hidden':'true'});const items=entry.doc.items.filter(i=>!['connector','pen'].includes(i.type)),box=bounds(items);const scale=Math.min(280/(box.w||1),120/(box.h||1));
    for(const item of items.slice(0,150))preview.append(el('rect',{x:20+(item.x-box.x)*scale,y:15+(item.y-box.y)*scale,width:Math.max(2,item.w*scale),height:Math.max(2,item.h*scale),fill:item.fill,stroke:'#9ab2a5','stroke-width':.5,rx:2}));if(!items.length){const t=el('text',{x:160,y:80,'text-anchor':'middle',fill:'#768e80','font-size':14});t.textContent='A fresh canvas';preview.append(t);}cover.append(preview);article.append(cover);
    const heading=document.createElement('h2');heading.textContent=entry.doc.name;article.append(heading);const meta=document.createElement('p');meta.textContent=`${entry.doc.items.length} objects · ${new Date(entry.updatedAt).toLocaleDateString()}`;article.append(meta);
    const actions=document.createElement('div');actions.className='boardactions';const action=(label,fn)=>{const b=document.createElement('button');b.textContent=label;b.onclick=fn;actions.append(b);return b;};
    if(entry.deletedAt!==null)action('Restore',()=>libraryAction(()=>library.restore(entry.id)));
    else{
      const star=action(entry.starred?'★ Starred':'☆ Star',()=>libraryAction(()=>library.star(entry.id)));star.setAttribute('aria-pressed',entry.starred);
      action('Rename',async()=>{const name=await requestName('Rename board',entry.doc.name);if(name)libraryAction(()=>library.rename(entry.id,name));});
      action('Copy',()=>libraryAction(()=>library.duplicate(entry.id)));
      action('Move to trash',()=>libraryAction(()=>library.trash(entry.id)));
      const label=document.createElement('label');label.textContent='Space ';const select=document.createElement('select');select.setAttribute('aria-label',`Space for ${entry.doc.name}`);const none=document.createElement('option');none.value='';none.textContent='No space';select.append(none);for(const space of library.state.spaces){const option=document.createElement('option');option.value=space.id;option.textContent=space.name;select.append(option);}select.value=entry.spaceId||'';select.onchange=()=>libraryAction(()=>library.move(entry.id,select.value||null));label.append(select);actions.append(label);
    }article.append(actions);$('boardlist').append(article);
  }
}
document.querySelectorAll('.brand').forEach(a=>a.onclick=e=>{e.preventDefault();showDashboard();});
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{dashView=b.dataset.view;dashSpace=null;renderDashboard();});
$('boardsearch').oninput=renderDashboard;$('boardsort').onchange=renderDashboard;$('newboard').onclick=createBoard;
$('addspace').onclick=async()=>{const name=await requestName('Create a space','',200);if(name)libraryAction(()=>library.addSpace(name));};
async function leaveCloud(){
  if(!cloudSession)return true;
  try{await cloudSession.flush();cloudSession.close();cloudSession=null;cloudPeople=[];$('people').textContent='';board=library?.state.activeId?new Board(library.get().doc):new Board();selected=[];return true;}catch(error){toast('Cloud changes need attention. Export your draft or reload the cloud version before leaving.');return false;}
}
async function openCloud(id,{discardDraft=false}={}){
  if(cloudSession&&cloudSession.base.id!==id&&!await leaveCloud())return;
  if(!cloudSession&&!$('workspace').hidden&&library?.state.activeId&&!persist())return;
  try{
    const snapshot=await cloudRequest(`boards/${id}`);cloudSession?.close();board=new Board(snapshot.doc);selected=[];gesture=null;deferredCloud=null;
    cloudSession=new CloudSession(snapshot,{
      onDocument(doc){
        if(gesture&&['move','resize'].includes(gesture.type)){deferredCloud=doc;return;}
        const delta=changesBetween(board.doc,doc);
        for(const key of ['past','future'])board[key]=board[key].flatMap(previous=>{try{return[applyChanges(previous,delta)];}catch{return[];}});
        board.doc=doc;selected=selected.filter(id=>doc.items.some(i=>i.id===id));render();
      },
      onStatus(message){$('save').textContent=message;if(cloudSession)render();},
      onPresence(people){cloudPeople=people;$('people').textContent=people.length?`${people.length+1} online`:'Only you';renderPresence();}
    });
    const savedDraft=localStorage.getItem('mirra.cloud.draft.'+id);
    if(!discardDraft&&savedDraft){const draft=JSON.parse(savedDraft);if(!equal(draft.doc,snapshot.doc)){if(draft.revision===snapshot.revision&&cloudSession.canEdit){board=new Board(draft.doc);cloudSession.setDocument(board.doc);toast('Restored your unsaved device draft.');}else toast('A previous device draft exists. Export it from Cloud before replacing it.');}}
    $('workspace').hidden=false;$('dashboard').hidden=true;$('clouddialog').close();location.hash='cloud/'+id;document.title=board.doc.name+' · Mirra Cloud';setTool('select');fit();render();
  }catch(error){$('cloudstatus').textContent=error.message;toast(error.message);}
}
async function showCloud(){
  $('clouddialog').showModal();$('cloudstatus').textContent='Connecting…';$('cloudboards').replaceChildren();$('uploadcloud').disabled=$('workspace').hidden||Boolean(cloudSession);$('reloadcloud').disabled=!cloudSession;$('cloudmembers').hidden=cloudSession?.base.role!=='owner';
  try{
    const {user}=await cloudRequest('me');$('cloudstatus').textContent=`Signed in as ${user.email}. Cloud boards are stored on the server.`;
    const {boards}=await cloudRequest('boards');for(const entry of boards){const b=document.createElement('button');b.textContent=`${entry.name} · ${entry.role}`;b.onclick=()=>openCloud(entry.id);$('cloudboards').append(b);}
    if(!boards.length)$('cloudboards').textContent='No cloud boards yet. Open a local board and save it to cloud.';
    if(cloudSession?.base.role==='owner'){
      const {members}=await cloudRequest(`boards/${cloudSession.base.id}/members`);$('memberlist').replaceChildren();for(const member of members){const row=document.createElement('div');row.textContent=`${member.email} · ${member.role} `;const remove=document.createElement('button');remove.textContent='Remove';remove.onclick=async()=>{try{await cloudRequest(`boards/${cloudSession.base.id}/members`,{method:'DELETE',body:{email:member.email}});$('clouddialog').close();await showCloud();}catch(error){$('cloudstatus').textContent=error.message;}};row.append(remove);$('memberlist').append(row);}
    }
  }catch(error){$('cloudstatus').textContent='Cloud connection unavailable. Use the hosted workspace and sign in to connect.';const signIn=document.createElement('a');signIn.href='/signin-with-chatgpt?return_to=/public/index.html';signIn.target='_top';signIn.textContent='Sign in for cloud access';$('cloudboards').append(signIn);}
}
$('cloud').onclick=showCloud;$('cloudhome').onclick=showCloud;$('closecloud').onclick=()=>$('clouddialog').close();$('refreshcloud').onclick=()=>{$('clouddialog').close();void showCloud();};
$('uploadcloud').onclick=async()=>{try{const snapshot=await cloudRequest('boards',{method:'POST',body:{doc:board.doc}});await openCloud(snapshot.id);}catch(error){$('cloudstatus').textContent=error.message;}};
$('reloadcloud').onclick=()=>{if(cloudSession)void openCloud(cloudSession.base.id,{discardDraft:true});};
const draftExport=document.createElement('button');draftExport.textContent='Export device draft';draftExport.onclick=()=>{try{if(!cloudSession)throw Error('Open a cloud board first');const raw=localStorage.getItem('mirra.cloud.draft.'+cloudSession.base.id);if(!raw)throw Error('No device draft is stored for this board');download('mirra-cloud-draft.json',JSON.stringify(JSON.parse(raw).doc),'application/json');}catch(error){$('cloudstatus').textContent=error.message;}};$('clouddialog').querySelector('.dialogbuttons').append(draftExport);
$('memberform').onsubmit=async event=>{event.preventDefault();try{await cloudRequest(`boards/${cloudSession.base.id}/members`,{method:'POST',body:{email:$('memberemail').value,role:$('memberrole').value}});$('clouddialog').close();await showCloud();}catch(error){$('cloudstatus').textContent=error.message;}};
window.addEventListener('beforeunload',event=>{if(cloudSession&&!equal(cloudSession.base.doc,board.doc)){event.preventDefault();event.returnValue='';}});
window.addEventListener('storage',e=>{if(e.key===LIBRARY_KEY){saveBlocked=true;$('save').textContent='Changed in another tab';toast('Another tab changed your board library. Export unsaved work, then reload.');if(!$('dashboard').hidden)renderDashboard();}});
window.addEventListener('resize',render);render();
const requested=location.hash.match(/^#board\/(.+)$/)?.[1];
if(storageError){$('save').textContent='Storage could not be restored';toast('Your existing library was preserved. Use Export to save new work; reload after fixing storage.');}
else if(requested){openBoard(requested);}
else{$('workspace').hidden=true;$('dashboard').hidden=false;document.title='Boards · Mirra';renderDashboard();}
const requestedCloud=location.hash.match(/^#cloud\/(.+)$/)?.[1];if(requestedCloud)void openCloud(requestedCloud);
