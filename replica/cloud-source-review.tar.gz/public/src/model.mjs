import {SHAPES,visualBox} from './geometry.mjs';
export const TYPES = new Set(['sticky', 'text', 'shape', 'frame', 'connector', 'pen', 'card']);
const clone = value => structuredClone(value);
const finite = n => typeof n === 'number' && Number.isFinite(n) && Math.abs(n) <= 1e7;
export function validateDocument(doc) {
  if (!doc || doc.version !== 1 || typeof doc.name !== 'string' || doc.name.length > 500 || !Array.isArray(doc.items) || doc.items.length > 100000) throw Error('Invalid board document');
  const ids = new Set();
  for (const item of doc.items) {
    if (!item || typeof item.id !== 'string' || !item.id || ids.has(item.id) || !TYPES.has(item.type)) throw Error('Invalid or duplicate item');
    ids.add(item.id);
    if (![item.x, item.y, item.w, item.h].every(finite) || item.w < 1 || item.h < 1) throw Error('Invalid item geometry');
    if (typeof item.text !== 'string' || item.text.length > 100000 || typeof item.fill !== 'string' || !/^#[0-9a-f]{6}$/i.test(item.fill)) throw Error('Invalid item content');
    for(const key of ['textColor','stroke'])if(item[key]!==undefined&&(typeof item[key]!=='string'||!/^#[0-9a-f]{6}$/i.test(item[key])))throw Error('Invalid style color');
    for(const [key,min,max] of [['fontSize',8,200],['strokeWidth',0,20],['rotation',-360,360],['opacity',0,1]])if(item[key]!==undefined&&(!finite(item[key])||item[key]<min||item[key]>max))throw Error(`Invalid ${key}`);
    for(const key of ['bold','italic','underline','autoFont','locked'])if(item[key]!==undefined&&typeof item[key]!=='boolean')throw Error(`Invalid ${key}`);
    if(item.shape!==undefined&&!SHAPES.includes(item.shape))throw Error('Invalid shape');
    if(item.textAlign!==undefined&&!['left','center','right'].includes(item.textAlign))throw Error('Invalid text alignment');
    if(item.route!==undefined&&!['straight','orthogonal','curve'].includes(item.route))throw Error('Invalid connector routing');
    if(item.lineStyle!==undefined&&!['solid','dashed','dotted'].includes(item.lineStyle))throw Error('Invalid line style');
    if(item.arrow!==undefined&&!['none','end','both'].includes(item.arrow))throw Error('Invalid arrow style');
    if(item.fontFamily!==undefined&&!['sans','serif','mono'].includes(item.fontFamily))throw Error('Invalid font family');
    if (item.type === 'pen' && (!Array.isArray(item.points) || item.points.length < 2)) throw Error('A drawing requires at least two points');
    if (item.points !== undefined && (!Array.isArray(item.points) || item.points.length > 100000 || item.points.some(p => !Array.isArray(p) || p.length !== 2 || !p.every(finite)))) throw Error('Invalid drawing');
  }
  for (const item of doc.items) if (item.type === 'connector') {
    if (!ids.has(item.from) || !ids.has(item.to) || item.from === item.to) throw Error('Invalid connector endpoints');
  }
  for (const item of doc.items) {
    if (item.groupId !== undefined && (typeof item.groupId !== 'string' || !item.groupId)) throw Error('Invalid group');
    if (item.parentId !== undefined) {
      const parent = doc.items.find(i => i.id === item.parentId);
      if (!parent || parent.type !== 'frame' || parent.id === item.id) throw Error('Invalid frame parent');
      const seen = new Set([item.id]); let node = parent;
      while (node) { if (seen.has(node.id)) throw Error('Cyclic frame nesting'); seen.add(node.id); node=doc.items.find(i=>i.id===node.parentId); }
    }
  }
  return clone(doc);
}
export function reconcileFrames(doc) {
  const frames=doc.items.filter(i=>i.type==='frame');
  for (const item of doc.items) {
    if(item.type==='connector')continue;
    const parent=frames.filter(f=>f.id!==item.id&&f.w*f.h>item.w*item.h&&item.x>=f.x&&item.y>=f.y&&item.x+item.w<=f.x+f.w&&item.y+item.h<=f.y+f.h).sort((a,b)=>a.w*a.h-b.w*b.h||(a.id===item.parentId?-1:b.id===item.parentId?1:a.id.localeCompare(b.id)))[0];
    if(parent)item.parentId=parent.id;else delete item.parentId;
  }
}
export function bounds(items) {
  if (!items.length) return { x: 0, y: 0, w: 1, h: 1 };
  items=items.map(visualBox);
  const x = Math.min(...items.map(i => i.x)), y = Math.min(...items.map(i => i.y));
  return { x, y, w: Math.max(...items.map(i => i.x + i.w)) - x, h: Math.max(...items.map(i => i.y + i.h)) - y };
}
export class Board {
  constructor(doc = { version: 1, name: 'Untitled board', items: [] }) {
    this.doc = validateDocument(doc); reconcileFrames(this.doc); this.past = []; this.future = [];
  }
  transact(fn) {
    const before = clone(this.doc);
    try { fn(this.doc); this.doc = validateDocument(this.doc); }
    catch (error) { this.doc = before; throw error; }
    if (JSON.stringify(before) === JSON.stringify(this.doc)) return false;
    this.past.push(before); if (this.past.length > 100) this.past.shift(); this.future = []; return true;
  }
  add(type, x, y, props = {}) {
    const id = crypto.randomUUID();
    this.transact(doc => {doc.items.push({ id, type, x, y, w: 180, h: 140, text: '', fill: '#f6e49b', ...props, id, type });reconcileFrames(doc);});
    return id;
  }
  update(ids, props) { this.transact(doc => { for (const item of doc.items) if (ids.includes(item.id)&&(!item.locked||(Object.keys(props).length===1&&typeof props.locked==='boolean'))) Object.assign(item, props);reconcileFrames(doc); }); }
  selection(ids, {descendants=false}={}) {
    const result=new Set(ids),groups=new Set(this.doc.items.filter(i=>result.has(i.id)&&i.groupId).map(i=>i.groupId));
    for(const i of this.doc.items)if(groups.has(i.groupId))result.add(i.id);
    if(descendants){let changed=true;while(changed){changed=false;for(const i of this.doc.items)if(i.parentId&&result.has(i.parentId)&&!result.has(i.id)){result.add(i.id);changed=true;}}}
    return [...result];
  }
  move(ids, dx, dy) { const expanded=this.selection(ids.filter(id=>!this.doc.items.find(i=>i.id===id)?.locked),{descendants:true});this.transact(doc => { for (const item of doc.items) if (expanded.includes(item.id) && !item.locked && item.type!=='connector') { item.x += dx; item.y += dy; }reconcileFrames(doc); }); }
  remove(ids) { const expanded=this.selection(ids);this.transact(doc => { const removed = new Set(expanded.filter(id => !doc.items.find(i => i.id === id)?.locked)); doc.items = doc.items.filter(i => !removed.has(i.id) && !(i.type === 'connector' && (removed.has(i.from) || removed.has(i.to))));reconcileFrames(doc); }); }
  duplicate(ids) {
    const expanded=this.selection(ids,{descendants:true});
    const items = this.doc.items.filter(i => expanded.includes(i.id) && i.type !== 'connector');
    const map = new Map(items.map(i => [i.id, crypto.randomUUID()]));
    const groups=new Map(items.filter(i=>i.groupId).map(i=>[i.groupId,crypto.randomUUID()]));
    const copies = items.map(i => ({ ...clone(i), id: map.get(i.id), x: i.x + 24, y: i.y + 24, locked: false, ...(i.groupId?{groupId:groups.get(i.groupId)}:{}),...(map.has(i.parentId)?{parentId:map.get(i.parentId)}:{}) }));
    for (const i of this.doc.items) if (i.type === 'connector' && map.has(i.from) && map.has(i.to)) copies.push({ ...clone(i), id: crypto.randomUUID(), from: map.get(i.from), to: map.get(i.to) });
    this.transact(doc => {doc.items.push(...copies);reconcileFrames(doc);}); return copies.map(i => i.id);
  }
  copySelection(ids) {
    const expanded=this.selection(ids,{descendants:true}),items=clone(this.doc.items.filter(i=>expanded.includes(i.id)&&i.type!=='connector'));
    const included=new Set(items.map(i=>i.id));
    for(const item of items)if(item.parentId&&!included.has(item.parentId))delete item.parentId;
    items.push(...clone(this.doc.items.filter(i=>i.type==='connector'&&included.has(i.from)&&included.has(i.to))));
    return JSON.stringify({version:1,name:'Selection',items});
  }
  pasteSelection(json,x,y) {
    const source=validateDocument(JSON.parse(json));if(!source.items.length)return[];
    const box=bounds(source.items.filter(i=>i.type!=='connector')),map=new Map(source.items.map(i=>[i.id,crypto.randomUUID()])),groups=new Map(source.items.filter(i=>i.groupId).map(i=>[i.groupId,crypto.randomUUID()]));
    const items=source.items.map(i=>({...clone(i),id:map.get(i.id),x:i.x+x-box.x,y:i.y+y-box.y,locked:false,...(i.parentId?{parentId:map.get(i.parentId)}:{}),...(i.groupId?{groupId:groups.get(i.groupId)}:{}),...(i.type==='connector'?{from:map.get(i.from),to:map.get(i.to)}:{})}));
    this.transact(doc=>{doc.items.push(...items);reconcileFrames(doc);});return items.map(i=>i.id);
  }
  bulkStickies(text,x,y,{fill='#f6e49b',columns=4}={}) {
    if(typeof text!=='string'||!Number.isInteger(columns)||columns<1||columns>12)throw Error('Invalid bulk input');
    const lines=text.split(/\r?\n/).map(line=>line.trim()).filter(Boolean);if(!lines.length||lines.length>500||lines.some(line=>line.length>3000))throw Error('Enter 1–500 non-empty lines, each up to 3000 characters');
    const items=lines.map((text,index)=>({id:crypto.randomUUID(),type:'sticky',x:x+(index%columns)*200,y:y+Math.floor(index/columns)*170,w:180,h:150,fill,text,autoFont:true}));
    this.transact(doc=>{doc.items.push(...items);reconcileFrames(doc);});return items.map(i=>i.id);
  }
  clearContent(ids) {this.transact(doc=>{for(const i of doc.items)if(ids.includes(i.id)&&!i.locked&&['sticky','shape','card'].includes(i.type))i.text='';});}
  resize(id,w,h) {
    const item=this.doc.items.find(i=>i.id===id);if(!item||item.locked||item.type==='connector')throw Error('Select an unlocked object to resize');
    this.transact(doc=>{const target=doc.items.find(i=>i.id===id),sx=w/target.w,sy=h/target.h;if(target.type==='pen')target.points=target.points.map(p=>[p[0]*sx,p[1]*sy]);target.w=w;target.h=h;reconcileFrames(doc);});
  }
  group(ids) {
    const expanded=this.selection(ids),items=this.doc.items.filter(i=>expanded.includes(i.id)&&i.type!=='connector');
    if(items.length<2)throw Error('Select at least two objects to group');
    if(items.some(i=>i.locked))throw Error('Unlock the selected objects before grouping');
    if(new Set(items.map(i=>i.parentId||null)).size>1)throw Error('Objects on different frames cannot be grouped');
    const groupId=crypto.randomUUID();this.transact(doc=>{for(const i of doc.items)if(expanded.includes(i.id))i.groupId=groupId;});return expanded;
  }
  ungroup(ids) {const expanded=this.selection(ids);this.transact(doc=>{for(const i of doc.items)if(expanded.includes(i.id))delete i.groupId;});return expanded;}
  frameSelection(ids) {
    const expanded=this.selection(ids,{descendants:true}),items=this.doc.items.filter(i=>expanded.includes(i.id)&&i.type!=='connector');
    if(!items.length)throw Error('Select objects to put in a frame');const box=bounds(items);
    return this.add('frame',box.x-32,box.y-40,{w:box.w+64,h:box.h+72,text:'New frame',fill:'#ffffff'});
  }
  align(ids, axis) {
    const items = this.doc.items.filter(i => ids.includes(i.id) && !i.locked && i.type !== 'connector'); const box = bounds(items);
    this.transact(doc => { for (const i of doc.items) if (items.some(j => j.id === i.id)) {
      if (axis === 'left') i.x = box.x;
      if (axis === 'center') i.x = box.x + (box.w - i.w) / 2;
      if (axis === 'right') i.x = box.x + box.w - i.w;
      if (axis === 'top') i.y = box.y;
      if (axis === 'middle') i.y = box.y + (box.h - i.h) / 2;
      if (axis === 'bottom') i.y = box.y + box.h - i.h;
    }reconcileFrames(doc); });
  }
  reorder(ids, front) { this.transact(doc => { const selected = doc.items.filter(i => ids.includes(i.id)); const rest = doc.items.filter(i => !ids.includes(i.id)); doc.items = front ? [...rest, ...selected] : [...selected, ...rest]; }); }
  undo() { if (!this.past.length) return false; this.future.push(clone(this.doc)); this.doc = this.past.pop(); return true; }
  redo() { if (!this.future.length) return false; this.past.push(clone(this.doc)); this.doc = this.future.pop(); return true; }
  serialize() { return JSON.stringify(this.doc); }
  static parse(json) { return new Board(JSON.parse(json)); }
}
