import{validateDocument}from'./model.mjs';
import{changesBetween,applyChanges,equal}from'./changes.mjs';
export async function cloudRequest(path,{method='GET',body}={}){
  const response=await fetch('/api/'+path,{method,headers:body?{'Content-Type':'application/json'}:{},...(body?{body:JSON.stringify(body)}:{})});
  const data=await response.json();if(!response.ok)throw Object.assign(new Error(data.error||'Cloud request failed'),{status:response.status,data});return data;
}
export class CloudSession{
  constructor(snapshot,{onDocument=()=>{},onStatus=()=>{},onPresence=()=>{},request=cloudRequest,events=true}={}){
    this.base=structuredClone(snapshot);this.local=validateDocument(snapshot.doc);this.onDocument=onDocument;this.onStatus=onStatus;this.onPresence=onPresence;this.request=request;this.clientId=crypto.randomUUID();this.closed=false;this.conflict=null;this.pending=null;this.inflight=null;
    if(events)this.connect();this.onStatus(this.canEdit?'Cloud saved':'Cloud · read only');
  }
  get canEdit(){return['owner','editor'].includes(this.base.role)&&!this.conflict;}
  connect(){
    this.source=new EventSource(`/api/boards/${this.base.id}/events?revision=${this.base.revision}`);
    this.source.addEventListener('board',event=>{try{const snapshot=JSON.parse(event.data);if(this.inflight){if(!this.remote||snapshot.revision>this.remote.revision)this.remote=snapshot;}else this.receive(snapshot);}catch(error){this.onStatus(error.message);}});
    this.source.addEventListener('presence',event=>{try{this.onPresence(JSON.parse(event.data).filter(p=>p.client_id!==this.clientId));}catch{}});
    this.source.addEventListener('revoked',()=>{this.conflict=Error('Access unavailable. Export your unsaved work.');this.onStatus(this.conflict.message);this.source.close();});
    this.source.onerror=()=>this.onStatus('Connection interrupted · retrying');
    this.source.onopen=()=>{this.onStatus(this.pending?'Cloud update pending':this.canEdit?'Live · cloud saved':'Live · read only');if(this.pending)void this.flush().catch(()=>{});};
    this.presenceTimer=setInterval(()=>{void this.presence().catch(()=>{});},10000);void this.presence().catch(()=>{});
  }
  async presence(point){if(this.closed)return;if(point)this.cursor=point;await this.request(`boards/${this.base.id}/presence`,{method:'POST',body:{clientId:this.clientId,...this.cursor}});}
  receive(snapshot){
    if(this.closed||this.conflict||snapshot.revision<this.base.revision)return;
    if(snapshot.revision===this.base.revision){if(snapshot.role!==this.base.role){this.base.role=snapshot.role;this.onStatus(this.canEdit?'Live · cloud saved':'Live · read only');this.onDocument(structuredClone(this.local));}return;}
    try{const pending=changesBetween(this.base.doc,this.local),next=applyChanges(snapshot.doc,pending);this.base=structuredClone(snapshot);this.local=next;this.onDocument(structuredClone(next));this.onStatus(pending.length?'Local changes pending':'Live · cloud saved');}
    catch(error){this.conflict=error;this.remote=snapshot;this.onStatus('Edit conflict · export draft or reload cloud');}
  }
  setDocument(doc){if(!this.canEdit)throw Error('This cloud board is read-only or has an unresolved conflict');this.local=validateDocument(doc);this.onStatus('Saving to cloud…');clearTimeout(this.saveTimer);this.saveTimer=setTimeout(()=>{void this.flush().catch(()=>{});},250);}
  async flush(){
    if(this.inflight){await this.inflight;if(!equal(this.base.doc,this.local))return this.flush();return;}
    if(this.conflict)throw this.conflict;if(this.closed)return;
    clearTimeout(this.saveTimer);
    this.inflight=(async()=>{
      while(!this.closed){
        if(!this.pending){const changes=changesBetween(this.base.doc,this.local);if(!changes.length)break;this.pending={operationId:crypto.randomUUID(),changes,sent:structuredClone(this.local)};}
        const pending=this.pending;
        let snapshot;try{snapshot=await this.request(`boards/${this.base.id}/changes`,{method:'POST',body:{operationId:pending.operationId,changes:pending.changes}});}
        catch(error){if([400,403,404,409].includes(error.status)){this.conflict=error;this.onStatus('Cloud edit needs attention · export draft');}else{this.onStatus('Offline · draft kept on this device');clearTimeout(this.retryTimer);this.retryDelay=Math.min(30000,(this.retryDelay||1000)*2);this.retryTimer=setTimeout(()=>{if(!this.closed)void this.flush().catch(()=>{});},this.retryDelay);}throw error;}
        const later=changesBetween(pending.sent,this.local);
        try{this.local=applyChanges(snapshot.doc,later);}catch(error){this.conflict=error;this.onStatus('Edit conflict · draft kept on this device');throw error;}
        this.base=structuredClone(snapshot);this.pending=null;this.retryDelay=0;clearTimeout(this.retryTimer);this.onDocument(structuredClone(this.local));
        if(this.remote){const remote=this.remote;this.remote=null;this.receive(remote);if(this.conflict)throw this.conflict;}
      }
      this.onStatus(this.canEdit?'Live · cloud saved':'Live · read only');
    })();
    try{await this.inflight;}finally{this.inflight=null;}
  }
  close(){this.closed=true;clearTimeout(this.saveTimer);clearTimeout(this.retryTimer);clearInterval(this.presenceTimer);this.source?.close();}
}
