import {validateDocument,reconcileFrames} from './model.mjs';
const fields=new Set(['type','x','y','w','h','text','fill','points','from','to','shape','groupId','parentId','locked','rotation','opacity','stroke','strokeWidth','lineStyle','arrow','route','textColor','fontSize','fontFamily','textAlign','bold','italic','underline','autoFont']);
const canonical=value=>value===undefined?'undefined':value===null||typeof value!=='object'?JSON.stringify(value):Array.isArray(value)?'['+value.map(canonical).join(',')+']':'{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}';
export const equal=(a,b)=>canonical(a)===canonical(b);
const state=(object,key)=>Object.hasOwn(object,key)?{present:true,value:structuredClone(object[key])}:{present:false};
export function changesBetween(before,after){
  validateDocument(before);validateDocument(after);const old=new Map(before.items.map(i=>[i.id,i])),next=new Map(after.items.map(i=>[i.id,i]));const changes=[];
  for(const item of before.items)if(!next.has(item.id))changes.push({kind:'delete',id:item.id,before:item});
  for(const [index,item]of after.items.entries()){
    const previous=old.get(item.id);
    if(!previous){changes.push({kind:'create',id:item.id,item,afterId:after.items[index-1]?.id||null});continue;}
    const updates=[];for(const key of new Set([...Object.keys(previous),...Object.keys(item)]))if(key!=='id'&&!equal(state(previous,key),state(item,key)))updates.push({key,before:state(previous,key),after:state(item,key)});
    if(updates.length)changes.push({kind:'update',id:item.id,updates});
  }
  if(before.name!==after.name)changes.push({kind:'name',before:before.name,after:after.name});
  const beforeOrder=before.items.filter(i=>next.has(i.id)).map(i=>i.id),afterOrder=after.items.filter(i=>old.has(i.id)).map(i=>i.id);
  if(!equal(beforeOrder,afterOrder))changes.push({kind:'order',before:beforeOrder,after:afterOrder});
  return changes;
}
export class Conflict extends Error{constructor(conflicts){super('Concurrent edits conflict. Your unsaved work is preserved.');this.conflicts=conflicts;}}
export function applyChanges(document,changes){
  if(!Array.isArray(changes)||changes.length>10000)throw Error('Invalid changes');
  const doc=structuredClone(document),conflicts=[];
  for(const change of changes){
    if(!change||typeof change.kind!=='string')throw Error('Invalid operation');
    const index=doc.items.findIndex(i=>i.id===change.id),item=doc.items[index];
    if(change.kind==='create'){
      if(change.id!==change.item?.id)throw Error('Invalid create');
      if(item){if(!equal(item,change.item))conflicts.push({id:change.id,field:'create'});continue;}
      const anchor=doc.items.findIndex(i=>i.id===change.afterId);doc.items.splice(anchor<0?doc.items.length:anchor+1,0,structuredClone(change.item));
    }else if(change.kind==='delete'){
      if(!item)continue;if(!equal(item,change.before))conflicts.push({id:change.id,field:'delete'});else doc.items.splice(index,1);
    }else if(change.kind==='update'){
      if(!item){conflicts.push({id:change.id,field:'deleted'});continue;}
      if(!Array.isArray(change.updates)||change.updates.length>fields.size)throw Error('Invalid field updates');
      for(const update of change.updates){
        if(!fields.has(update.key)||typeof update.before?.present!=='boolean'||typeof update.after?.present!=='boolean')throw Error('Invalid field update');
        const current=state(item,update.key);if(equal(current,update.after))continue;
        if(!equal(current,update.before)){conflicts.push({id:change.id,field:update.key});continue;}
        if(update.after.present)item[update.key]=structuredClone(update.after.value);else delete item[update.key];
      }
    }else if(change.kind==='name'){
      if(doc.name!==change.before&&doc.name!==change.after)conflicts.push({field:'name'});else doc.name=change.after;
    }else if(change.kind==='order'){
      if(!Array.isArray(change.before)||!Array.isArray(change.after)||new Set(change.before).size!==change.before.length||!equal([...change.before].sort(),[...change.after].sort()))throw Error('Invalid stacking order');
      const set=new Set(change.before),present=doc.items.filter(i=>set.has(i.id));
      if(!equal(present.map(i=>i.id),change.before)&&!equal(present.map(i=>i.id),change.after)){conflicts.push({field:'order'});continue;}
      const map=new Map(present.map(i=>[i.id,i]));let order=0;doc.items=doc.items.map(i=>set.has(i.id)?map.get(change.after[order++]):i);
    }else throw Error('Unknown operation');
  }
  if(conflicts.length)throw new Conflict(conflicts);
  validateDocument(doc);reconcileFrames(doc);return validateDocument(doc);
}
